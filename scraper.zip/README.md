Scraper and Order bot for hunting preorders

Working on:
1. Making good Scrapers to track PREORDERS Pokemon Products on websites: https://fantasiastore.it/ https://www.gamestop.it/ and https://federicstore.it/
2. Making a good logging and database system

Goals:
1. Scan E-Commerce websites looking for products and avaiability, putting all information into a database and keep track of sites every X minutes/hour. Mainly on PRE-ORDERS products
2. Send notification via Telegram and Discord when a new product will be listed
3. Module for automatic buy of products if needed using a trusted account
4. Web-GUI to manage and check if program is working file or there are errors

I'm not a programmer, i'm using AI to making this program, i'm just a IT guy that want to make some programs, if someone wanna help that's great.
