# Configurazione generale
SCRAPING_INTERVAL = 30  # intervallo di scraping in secondi
